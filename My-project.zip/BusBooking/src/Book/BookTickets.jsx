import React, { useState } from 'react';
import axios from 'axios';
import './BookTickets.css';

const BookTickets = () => {
  const [formData, setFormData] = useState({ searchQuery: '', selectedBook: null, quantity: 1 });
  const [step, setStep] = useState(1);
  const [confirmation, setConfirmation] = useState(false);
  const [availableBooks, setAvailableBooks] = useState([]);
  const [selectedQuantity, setSelectedQuantity] = useState(1);

  // Sample book data
  const allBooks = [
    { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price: 10.99 },
    { id: 2, title: '1984', author: 'George Orwell', price: 8.99 },
    { id: 3, title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 12.99 },
    { id: 4, title: 'Moby Dick', author: 'Herman Melville', price: 15.99 },
    { id: 5, title: 'Pride and Prejudice', author: 'Jane Austen', price: 9.99 },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const filteredBooks = allBooks.filter(book =>
      book.title.toLowerCase().includes(formData.searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(formData.searchQuery.toLowerCase())
    );
    setAvailableBooks(filteredBooks);
    setStep(2);
  };

  const handleBookSelect = (book) => {
    setFormData({ ...formData, selectedBook: book });
    setStep(3);
  };

  const handleConfirmBooking = async (e) => {
    e.preventDefault();
    const bookingData = {
      title: formData.selectedBook.title,
      author: formData.selectedBook.author,
      quantity: selectedQuantity,
    };

    try {
      const response = await axios.post('http://localhost:3001/bookings', bookingData);
      if (response.status === 201) {
        setConfirmation(true);
      } else {
        alert('Booking failed!');
      }
    } catch (error) {
      console.error('Error booking:', error);
      alert('There was an error with your booking.');
    }
  };

  return (
    <div className="book-tickets-container">
      <h2>Book Your Favorite Books</h2>
      {confirmation ? (
        <div className="confirmation">
          <h3>Booking Confirmed!</h3>
          <p>Thank you for your order. A confirmation email has been sent to you.</p>
        </div>
      ) : (
        <form className="book-tickets-form" onSubmit={step === 1 ? handleSearch : handleConfirmBooking}>
          {/* Step 1: Search for Books */}
          {step === 1 && (
            <div className="step step-1 active">
              <label htmlFor="searchQuery">Search by Book Title or Author:</label>
              <input
                type="text"
                id="searchQuery"
                name="searchQuery"
                value={formData.searchQuery}
                onChange={handleChange}
                placeholder="Enter book title or author"
                required
              />
              <button type="submit" className="primary-btn">Search</button>
            </div>
          )}

          {/* Step 2: Select a Book */}
          {step === 2 && (
            <div className="step step-2 active">
              <h3>Select a Book</h3>
              <div className="book-options">
                {availableBooks.length > 0 ? (
                  availableBooks.map((book) => (
                    <div
                      key={book.id}
                      className="book-option"
                      onClick={() => handleBookSelect(book)}
                    >
                      <h4>{book.title}</h4>
                      <p>{book.author}</p>
                      <p className="price">${book.price.toFixed(2)}</p>
                    </div>
                  ))
                ) : (
                  <p>No books found. Please try a different search.</p>
                )}
              </div>
              <button type="button" className="secondary-btn" onClick={() => setStep(1)}>Back</button>
            </div>
          )}

          {/* Step 3: Confirm Booking */}
          {step === 3 && (
            <div className="step step-3 active">
              <h3>Confirm Your Booking</h3>
              <h4>Selected Book: {formData.selectedBook?.title}</h4>
              <label htmlFor="quantity">Quantity:</label>
              <input
                type="number"
                id="quantity"
                name="quantity"
                value={selectedQuantity}
                onChange={(e) => setSelectedQuantity(e.target.value)}
                min="1"
                required
              />
              <button type="button" className="secondary-btn" onClick={() => setStep(2)}>Back</button>
              <button type="submit" className="primary-btn">Confirm Booking</button>
            </div>
          )}
        </form>
      )}
    </div>
  );
};

export default BookTickets;
