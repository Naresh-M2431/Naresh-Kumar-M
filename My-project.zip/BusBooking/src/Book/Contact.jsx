import React from 'react';
import './Contact.css'; // Ensure to create this CSS file

const Contact = () => {
  return (
    <div className="contact-container">
      <h2>Contact Us</h2>
      <p>We’d love to hear from you! Whether you have a question about our eBooks, need assistance, or just want to share your feedback, feel free to reach out.</p>

      <div className="contact-info">
        <h3>Get in Touch</h3>
        <form className="contact-form">
          <label htmlFor="name">Your Name:</label>
          <input type="text" id="name" name="name" required />

          <label htmlFor="email">Your Email:</label>
          <input type="email" id="email" name="email" required />

          <label htmlFor="message">Message:</label>
          <textarea id="message" name="message" rows="4" required></textarea>

          <button type="submit" className="submit-btn">Send Message</button>
        </form>
      </div>

      <div className="additional-info">
        <h3>Our Location</h3>
        <p>123 Book Street, Read City, BC 12345</p>
        
        <h3>Follow Us</h3>
        <div className="social-media">
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
          <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
        </div>
      </div>
    </div>
  );
};

export default Contact;

